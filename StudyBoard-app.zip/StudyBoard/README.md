# Study Board — fiches de révision

Application de révision **100 % autonome** (un seul fichier : `index.html` + dossier `media`).
SES · HGGSP · Histoire · Anglais — fiches de cours enrichies, cartes (mode Quizlet),
mode Écrire, mode Associer, quiz, défis express variés (vrai/faux, à trous,
remise en ordre, intrus, classement), **révision audio**, thème clair/sombre,
responsive mobile.

---

## ▶ Comment l'ouvrir

### Sur ton téléphone (le plus simple)
1. Décompresse ce ZIP sur ton téléphone.
2. Touche `index.html` → il s'ouvre dans ton navigateur.
   *(Sur iPhone : dans l'app « Fichiers », touche `index.html` → Partager →
   « Ouvrir dans Safari » si besoin.)*
3. Tout fonctionne hors-ligne. Garde le dossier tel quel : l'app a besoin de
   `media/` (audios) à côté d'`index.html`.

### Sur un ordinateur
Double-clic sur `index.html` (Chrome, Firefox, Safari, Edge…).

> 💡 Ton avancement (cartes mémorisées, étoiles des défis, thème) est conservé
> **localement dans le navigateur** de l'appareil où tu ouvres le fichier.

---

## 🎧 Révision audio (nouveau)

Sur chaque fiche, un lecteur **« Réviser en écoutant »** lance un récapitulatif
audio complet du cours, lu par une voix claire : définitions à répéter, chiffres
clés, mécanismes, pièges et mini auto-test final.

- `media/audio/ses-croissance.mp3` — La croissance économique
- `media/audio/hggsp-guerre.mp3` — Conflits et modes de résolution
- `media/audio/hggsp-cartographier.mp3` — Cartographier les guerres
- `media/audio/histoire-1929.mp3` — La crise de 1929
- `media/audio/anglais-heroes.mp3` — Heroes & superheroes (vocabulaire anglais)

Le dossier `media/*.m4a` contient aussi tes notes vocales d'origine (bouton
« prise de notes originale » sur chaque fiche).

---

## ☁ Pour y accéder depuis ton téléphone (GitHub)

### Option A — dépôt **privé** (recommandé)
1. Dans GitHub (web ou app) : **+ → New repository** → nomme-le (ex. `study-board`),
   coche **Private** → **Create repository**.
2. Sur la page du dépôt : **Add file → Upload files** → dépose `index.html`,
   le dossier `media/` entier, et `README.md` → **Commit changes**.
3. Sur ton téléphone : dans l'app GitHub, ouvre le dépôt, puis **télécharge** le
   fichier pour l'ouvrir en local (GitHub ne permet pas d'afficher la page en
   direct dans un dépôt privé sans compte payant).

### Option B — lien direct (dépôt **public** + GitHub Pages, gratuit)
1. Crée le dépôt en **Public** et dépose les mêmes fichiers.
2. **Settings → Pages** → Source : `main` → Save.
3. Quelques minutes après, ton app est en ligne :
   `https://<ton-pseudo>.github.io/<nom-du-dépôt>/` — ouvrable sur téléphone.

> Pour un lien public immédiat sans compte : Netlify Drop ou tiiny.host
> (glisser-déposer `index.html` + `media/` → URL tout de suite).

---

## 🔧 Notes de maintenance (si tu régénères le site)
Sources dans le projet : `contenu.py` (contenu), `generateur.py` (gabarit),
`enrich.py` (enrichissements v5), `v6patch.py` (fiches attractives + défis v6),
`audio_patch.py` (lecteur audio). Régénération complète, **dans cet ordre** :
```
python3 generateur.py
python3 enrich.py      # lance automatiquement v6patch.py puis audio_patch.py
```
⚠ Sans `enrich.py` après `generateur.py`, tous les enrichissements disparaissent.

*Fichier généré automatiquement — ne pas éditer le HTML à la main.*
